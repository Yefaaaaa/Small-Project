from sqlalchemy import create_engine
from sqlalchemy import Column, func
from sqlalchemy import Integer, VARCHAR, SmallInteger, TIMESTAMP,ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Create an engine
engine = create_engine('mysql+pymysql://root:password@127.0.0.1:3306/yefa?charset=utf8',max_overflow = 5)

Base = declarative_base()

class Questionnaire(Base):
    """
    问卷主表
    """
    __tablename__ = 'questionnaire_master'
    id = Column(Integer, primary_key=True)
    title = Column(VARCHAR(32))
    question_num = Column(SmallInteger)
    join_num = Column(Integer, default=0)
    status = Column(SmallInteger, default=1)
    c_time = Column(TIMESTAMP, server_default=func.now())
    e_time = Column(TIMESTAMP)


class QuestionType(Base):
    """
    问题类型表
    """
    __tablename__ = 'question_type'
    id = Column(Integer, primary_key=True)
    name = Column(VARCHAR(16))


class Question(Base):
    """
    题目表
    """
    __tablename__ = 'question'
    id = Column(Integer, primary_key=True)
    title = Column(VARCHAR(256))
    type_id = Column(Integer, ForeignKey('question_type.id'))
    questionnaire_id = Column(Integer, ForeignKey('questionnaire_master.id'))


class QuestionOption(Base):
    """
    问题选项表
    """
    __tablename__ = 'question_option'
    id = Column(Integer, primary_key=True)
    question_id = Column(Integer, ForeignKey('question.id'))
    content = Column(VARCHAR(256))


class QuestionnaireDetail(Base):
    """
    问卷详细
    """
    __tablename__ = 'questionnaire_detail'
    id = Column(Integer, primary_key=True)
    number = Column(Integer)
    questionnaire_id = Column(Integer, ForeignKey('questionnaire_master.id'))
    question_id = Column(Integer, ForeignKey('question.id'))
    option_id = Column(Integer, ForeignKey('question_option.id'))
    answer = Column(VARCHAR(256))

# 初始化
def init_db():
    Base.metadata.create_all(engine)


def drop_db():
    Base.metadata.drop_all(engine)


# drop_db()
init_db()
Session = sessionmaker(bind=engine)
oper = Session()
# 添加数据
# q = Questionnaire(title='课题调查', question_num=10, join_num=0, status=1, e_time='20170903')
# # w = Questionnaire(title='尝试', question_num=3, join_num=0, status=1, e_time='20170904')
# oper.add(q)
# # oper.add(w)
# res = oper.commit()

