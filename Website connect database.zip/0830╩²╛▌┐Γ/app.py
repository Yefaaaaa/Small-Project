#!/usr/bin/env python  
# -*- coding: utf-8 -*-  
# author: xin lan 2017/8/30
from tornado import web, httpserver, ioloop
from Survey import oper
from Survey  import Questionnaire



class MainPageHandler(web.RequestHandler):
    def get(self, *args, **kwargs):
        self.render('index.html')

class AddQuestionnaireHandler(web.RequestHandler):
    def post(self, *args, **kwargs):
        questionnaire = {}
        questionnaire['title'] = self.get_argument('title')
        questionnaire['question_num'] = self.get_argument('question_num')
        questionnaire['e_time'] = self.get_argument('e_time')

        q = Questionnaire(**questionnaire)
        oper.add(q)
        try:
            oper.commit()
            self.write('添加成功！')
        except Exception as e:
            print(e)
            self.write('添加失败！')

class QuestionnaireListHandler(web.RequestHandler):
    def get(self, *args, **kwargs):
        data = oper.query(Questionnaire).all()
        self.render('questionnaire.html', data=data)

application = web.Application([
            (r"/", MainPageHandler),
            (r"/add_questionnaire", AddQuestionnaireHandler),
            (r"/qnairelist", QuestionnaireListHandler),
        ])

if __name__ == '__main__':
    
    http_server = httpserver.HTTPServer(application)
    http_server = application
    http_server.listen(8000)
    ioloop.IOLoop.current().start()


