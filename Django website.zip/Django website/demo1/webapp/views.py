from django.shortcuts import render
from django.http import HttpResponse
from .models import NovelCopy
from .models import ChapterCopy

# Create your views here.
# def index(request):
#     return HttpResponse('Hello World')

def index(request):
    novelcopy = NovelCopy.objects.filter().order_by('?')[:4]  # check the database data
    context = {
        'novels': novelcopy,
    }
    return render(request,'index.html',context=context)  # connect with the html
