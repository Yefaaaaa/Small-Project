from __future__ import unicode_literals
from django.db import models

# Create your models here.
class Chapter(models.Model):
    chapterid = models.AutoField(primary_key=True)
    novelid = models.ForeignKey('Novel', models.DO_NOTHING, db_column='novelid')
    title = models.CharField(max_length=100)
    content = models.TextField()

    class Meta:
        managed = False
        db_table = 'chapter'


class ChapterCopy(models.Model):
    chapterid = models.AutoField(primary_key=True)
    novelid = models.ForeignKey('NovelCopy', models.DO_NOTHING, db_column='novelid')
    title = models.CharField(max_length=100)
    content = models.TextField()

    class Meta:
        managed = False
        db_table = 'chapter_copy'


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class Novel(models.Model):
    novelid = models.AutoField(primary_key=True)
    type = models.IntegerField()
    novelname = models.CharField(max_length=100)
    novelimg = models.CharField(max_length=100)
    description = models.TextField()
    state = models.CharField(max_length=20)
    author = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'novel'


class NovelCopy(models.Model):
    novelid = models.AutoField(primary_key=True)
    type = models.IntegerField()
    sort = models.CharField(max_length=100)
    novelname = models.CharField(max_length=100)
    novelimg = models.CharField(max_length=100)
    description = models.TextField()
    state = models.CharField(max_length=20)
    author = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'novel_copy'