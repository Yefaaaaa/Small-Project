import  requests
import re  # 正则表达式
import urllib.request
import os

# 正则表达式的元字符
# . 匹配任意字符   默认是不匹配换行和制表
# * 匹配前面的元字符的0次到多次


def get_response(url):
    response = requests.get(url).text
    return response   # return website source code

def get_content(html):  # find the video in the source code, and then return
    reg = re.compile((r'<div class="j-r-list-c">.*? </div>.*?</div>'),re.S)
    return re.findall(reg,html)

def get_mp4_url(response):  # 获取视频的url地址
    reg =re.compile(r'data-mp4="(.*?)"')
    return re.findall(reg,response)

def get_mp4_name(response):  # 获取视频的名字
    reg = re.compile('<a href="/detail-.{8}.html">(.*?)</a>')
    return re.findall(reg, response)  # findall return a list, not matter how many elements

def download_mp4(mp4_url,path):
    path = ''.join(path.split())
    path = 'C:\\Project\\Python\\Online Class\\video_catcher\\download\\{}.mp4'.format(path)  # video address
    # Method 1
    if not os.path.exists(path):
        urllib.request.urlretrieve(mp4_url,path)  # 下载视频
    # Method 2
        # content = get_response(mp4_url)
        # with open (path,'wb') as f:
        #     f.write(content)

def get_url_name(start_url):
    html = get_response(start_url)
    content = get_content(html)
    for i in content:
        mp4_url = get_mp4_url(i)
        if mp4_url:
            mp4_name = get_mp4_name(i)
            print(mp4_url[0], mp4_name[0])
            try:   # error detection
                download_mp4(mp4_url[0], mp4_name[0])
            except:
                continue

def main():
    [get_url_name(start_url) for start_url in start_urls]

if __name__ == '__main__':
    # start_url is global variable
    start_urls = ['http://www.budejie.com/{}'.format(i) for i in range(2,10)]  # page number increase, which can be check on website link
    main()






